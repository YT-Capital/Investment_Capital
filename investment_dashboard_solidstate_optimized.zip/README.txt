Open index.html in a browser to view the prototype.
This is a static prototype using TailwindCDN and Chart.js CDN.
